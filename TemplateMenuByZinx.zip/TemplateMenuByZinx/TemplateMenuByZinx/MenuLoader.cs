﻿using MelonLoader;
using Photon.Pun;
using TemplateMenuByZinx.Menu;
using UnityEngine;

namespace TemplateMenuByZinx
{
	public class MenuLoader : MelonMod
	{
		public bool menuInitialized;
		public override void OnUpdate()
		{
			if (!this.menuInitialized)
			{
				this.menuInitialized = true;
			}

			Menu.Menu.Prefix();
			if (!PhotonNetwork.IsConnected)
			{
				PhotonNetwork.ConnectUsingSettings();
			}
		}
	}
}

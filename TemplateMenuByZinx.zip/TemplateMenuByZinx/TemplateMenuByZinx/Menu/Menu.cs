﻿using System;
using System.Linq;
using easyInputs;
using ExitGames.Client.Photon;
using Photon.Pun;
using PlayFab.ClientModels;
using PlayFab;
using GorillaNetworking;
using UnityEngine;
using UnhollowerBaseLib;
using UnityEngine.UI;
using System.Reflection;

namespace TemplateMenuByZinx.Menu
{
	public class Menu
	{
		#region Main Stuff Dont Touch!
		private static GameObject menu = null;
		private static GameObject canvasObj = null;
		private static GameObject reference = null;
		private static GameObject LHandVolocityChecker = null;
		private static GameObject button1 = null;
		private static GameObject button2 = null;
		private static GameObject button3 = null;
		private static GameObject button4 = null;
		private static GameObject button5 = null;
		private static GameObject button6 = null;
		private static GameObject button7 = null;
		public static Material MenuTheme = new Material(Shader.Find("Sprites/Default"));
		public static string MenuColorType = "normal";
		private static float offset;
		private static float lastClickTime = 0.0f;
		public static float cooldownDuration = 0.25f;
		private static Color ButtonClicked;
		public static string BackColorType = "cyan";
		private static Color BackColor;
		private static Color ButtonNotClicked;
		public static float timeleft;
		public static float updateInterval = 0.5f;
		public static float proximityRange = 0.015f;
		#endregion
		#region Page Manager
		public static bool[] Page1ButtonActive = new bool[22];// always keep this 1 above the amount of buttons there is	
		public static string Page = "1"; // ignore this
        #endregion
        #region Platforms stuff
        public static GameObject BetterplatformR = null;
		public static GameObject BetterplatformL = null;
		public static bool BetterplatformLSpawned = false;
		public static bool BetterplatformRSpawned = false;
        #endregion
        #region Platform Manager
        public static void DrawPlatL()
		{
			BetterplatformL = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(BetterplatformL.GetComponent<Rigidbody>());
			UnityEngine.Object.Destroy(BetterplatformL.GetComponent<BoxCollider>());
			UnityEngine.Object.Destroy(BetterplatformL.GetComponent<Renderer>());
			BetterplatformL.transform.localScale = new Vector3(0.25f, 0.3f, 0.25f);
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
			//UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
			gameObject.transform.parent = BetterplatformL.transform;
			gameObject.transform.rotation = Quaternion.identity;
			gameObject.transform.localScale = new Vector3(0.1f, 1f, 1f);
			gameObject.GetComponent<Renderer>().material = MenuTheme;
			gameObject.transform.position = new Vector3(0.02f, 0f, 0f);
		}
		public static void BetterPlatforms(string type)
		{
			if (type == "Normal")
			{
				if (EasyInputs.GetGripButtonDown(EasyHand.LeftHand) && BetterplatformL == null)
				{ DrawPlatL(); }
				if (EasyInputs.GetGripButtonDown(EasyHand.RightHand) && BetterplatformR == null)
				{ DrawPlatR(); }
				if (EasyInputs.GetGripButtonDown(EasyHand.LeftHand) && BetterplatformL != null && !BetterplatformLSpawned)
				{
					BetterplatformL.transform.position = GorillaLocomotion.Player.Instance.leftHandTransform.position;
					BetterplatformL.transform.rotation = GorillaLocomotion.Player.Instance.leftHandTransform.rotation;

					BetterplatformLSpawned = true;
				}
				if (EasyInputs.GetGripButtonDown(EasyHand.RightHand) && BetterplatformR != null && !BetterplatformRSpawned)
				{
					BetterplatformR.transform.position = GorillaLocomotion.Player.Instance.rightHandTransform.position;
					BetterplatformR.transform.rotation = GorillaLocomotion.Player.Instance.rightHandTransform.rotation;

					BetterplatformRSpawned = true;
				}
				if (!EasyInputs.GetGripButtonDown(EasyHand.LeftHand) && BetterplatformL != null)
				{
					BetterplatformL.AddComponent<Rigidbody>();
					UnityEngine.Object.Destroy(BetterplatformL, 3f);
					BetterplatformL = null;
					BetterplatformLSpawned = false;

				}
				if (!EasyInputs.GetGripButtonDown(EasyHand.RightHand) && BetterplatformR != null)
				{
					BetterplatformR.AddComponent<Rigidbody>();
					UnityEngine.Object.Destroy(BetterplatformR, 3f);
					BetterplatformR = null;
					BetterplatformRSpawned = false;

				}
			}
		}
		public static void DrawPlatR()
		{
			BetterplatformR = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(BetterplatformR.GetComponent<Rigidbody>());
			UnityEngine.Object.Destroy(BetterplatformR.GetComponent<BoxCollider>());
			UnityEngine.Object.Destroy(BetterplatformR.GetComponent<Renderer>());
			BetterplatformR.transform.localScale = new Vector3(0.25f, 0.3f, 0.25f);
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
			//UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
			gameObject.transform.parent = BetterplatformR.transform;
			gameObject.transform.rotation = Quaternion.identity;
			gameObject.transform.localScale = new Vector3(0.1f, 1f, 1f);
			gameObject.GetComponent<Renderer>().material = MenuTheme;
			gameObject.transform.position = new Vector3(-0.02f, 0f, 0f);
		}
        #endregion

        #region Menu
        public static void Draw()
		{
			menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
			UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
			UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
			menu.transform.localScale = new Vector3(0.1f, 0.31f, 0.41f);
			GameObject gameObject1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(gameObject1.GetComponent<Rigidbody>());
			UnityEngine.Object.Destroy(gameObject1.GetComponent<BoxCollider>());
			gameObject1.transform.parent = menu.transform;
			gameObject1.transform.rotation = Quaternion.identity;
			gameObject1.GetComponent<Renderer>().material.color = BackColor;
			gameObject1.transform.position = new Vector3(0.045f, 0f, 0f);
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
			UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
			gameObject.transform.parent = menu.transform;
			gameObject.transform.rotation = Quaternion.identity;
			gameObject.GetComponent<Renderer>().material.color = Color.black;
			gameObject.transform.position = new Vector3(0.05f, 0f, 0f);
			gameObject.transform.localScale = new Vector3(0.1f, 1.27f, 0.97f);
			gameObject1.transform.localScale = new Vector3(0.05f, 1.3f, 1f);
			canvasObj = new GameObject();
			canvasObj.transform.parent = menu.transform;
			Canvas canvas = canvasObj.AddComponent<Canvas>();
			CanvasScaler canvasScaler = canvasObj.AddComponent<CanvasScaler>();
			canvasObj.AddComponent<GraphicRaycaster>();
			canvas.renderMode = RenderMode.WorldSpace;
			canvasScaler.dynamicPixelsPerUnit = 1000f;
			GameObject gameObject2 = new GameObject();
			gameObject2.transform.parent = canvasObj.transform;
			Text text = gameObject2.AddComponent<Text>();
			text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
			text.text = "Template Menu"; // change the name poo poo head
			text.fontSize = 1;
			text.alignment = TextAnchor.MiddleCenter;
			text.resizeTextForBestFit = true;
			text.resizeTextMinSize = 0;
			RectTransform component = text.GetComponent<RectTransform>();
			component.localPosition = Vector3.zero;
			component.sizeDelta = new Vector2(0.28f, 0.05f);
			component.position = new Vector3(0.06f, 0f, 0.17f);
			component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
		}
		#endregion
		#region Buttons Dont Touch Or Everything Destroys!
		public static void Drawsingleclickbutton(ref GameObject ButtonObj, string Text, float textypos, float buttonypos, ref bool Mod, int index)
		{
			if (ButtonObj == null)
			{
				ButtonObj = CreateButton(Text, textypos, buttonypos, ref Mod);
			}

			float distance = Vector3.Distance(ButtonObj.transform.position, reference.transform.position);
			if (distance <= proximityRange && Time.time - lastClickTime > cooldownDuration)
			{
				Mod = !Mod;
				ButtonObj.GetComponent<Renderer>().material.color = Mod ? ButtonClicked : ButtonNotClicked;
				lastClickTime = Time.time;
				GameObject.Destroy(menu);
				menu = null;
			}

			Page1ButtonActive[index] = Mod;
		}

		private static GameObject CreateButton(string Text, float textypos, float buttonypos, ref bool Mod)
		{
			GameObject ButtonObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
			UnityEngine.Object.Destroy(ButtonObj.GetComponent<Rigidbody>());
			UnityEngine.Object.Destroy(ButtonObj.GetComponent<BoxCollider>());
			ButtonObj.transform.parent = menu.transform;
			ButtonObj.transform.rotation = menu.transform.rotation;
			ButtonObj.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
			ButtonObj.transform.localPosition = new Vector3(0.56f, 0f, buttonypos - offset);
			Text textComponent = new GameObject { transform = { parent = canvasObj.transform } }.AddComponent<Text>();
			textComponent.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
			textComponent.text = Text;
			textComponent.color = Color.white;
			textComponent.fontSize = 1;
			textComponent.alignment = TextAnchor.MiddleCenter;
			textComponent.resizeTextForBestFit = true;
			textComponent.resizeTextMinSize = 0;
			RectTransform textTransform = textComponent.GetComponent<RectTransform>();
			textTransform.localPosition = Vector3.zero;
			textTransform.sizeDelta = new Vector2(0.2f, 0.03f);
			textTransform.localPosition = new Vector3(0.064f, 0f, textypos - offset / 2.55f);
			textTransform.rotation = ButtonObj.transform.rotation * Quaternion.Euler(180f, 90f, 90f);

			ButtonObj.GetComponent<Renderer>().material.color = Mod ? ButtonClicked : ButtonNotClicked;

			return ButtonObj;
		}

		#endregion
		public static void Prefix()
		{
            #region Dont Touch This Stuff!
            if (EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu == null)
			{
				// dont mess with this or your menu wont work
				Draw();
				if (reference == null)
				{
					reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
					GameObject.Destroy(reference.GetComponent<MeshRenderer>());
					GameObject.Destroy(reference.GetComponent<SphereCollider>());
					reference.transform.parent = GorillaLocomotion.Player.Instance.rightHandTransform;
					reference.transform.localPosition = new Vector3(0.0185f, -0.009f, 0.1f);
					reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);

				}
				// this kinda usless
				if (LHandVolocityChecker == null)
				{
					LHandVolocityChecker = GameObject.CreatePrimitive(PrimitiveType.Cube);
					LHandVolocityChecker.AddComponent<Rigidbody>();
					GameObject.Destroy(LHandVolocityChecker.GetComponent<MeshRenderer>());
					GameObject.Destroy(LHandVolocityChecker.GetComponent<BoxCollider>());
					LHandVolocityChecker.GetComponent<Rigidbody>().useGravity = false;
					LHandVolocityChecker.transform.parent = GorillaLocomotion.Player.Instance.leftHandTransform;
					LHandVolocityChecker.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);

				}
			}
			else
			{
				if (!EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu != null)
				{
					// dont mess with this or your menu wont work
					
					menu.transform.parent = null;
					menu.AddComponent<Rigidbody>();
					float scaleFactor = 5f;
					menu.GetComponent<Rigidbody>().velocity = LHandVolocityChecker.GetComponent<Rigidbody>().velocity * scaleFactor;
					menu.GetComponent<Rigidbody>().useGravity = true;
					menu.GetComponent<Rigidbody>().drag = 0.05f;
					menu.GetComponent<Rigidbody>().angularDrag = 0.05f;
					menu.GetComponent<Rigidbody>().angularVelocity = new Vector3(UnityEngine.Random.Range(-33, 33), UnityEngine.Random.Range(-33, 33), UnityEngine.Random.Range(-33, 33));

					GameObject.Destroy(menu, 3);
					GameObject.Destroy(button1, 3);
					GameObject.Destroy(button2, 3);
					GameObject.Destroy(button3, 3);
					GameObject.Destroy(button4, 3);
					GameObject.Destroy(button5, 3);
					GameObject.Destroy(button6, 3);
					GameObject.Destroy(button7, 3);
					GameObject.Destroy(LHandVolocityChecker, 3);
					GameObject.Destroy(reference);
					menu = null;
					reference = null;
					LHandVolocityChecker = null;
					button1 = null;
					button2 = null;
					button3 = null;
					button4 = null;
					button5 = null;
					button6 = null;
					button7 = null;

				}
			}
			if (EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu != null)
			{
				// dont mess with this or your menu wont work
				menu.transform.position = GorillaLocomotion.Player.Instance.leftHandTransform.position;
				menu.transform.rotation = GorillaLocomotion.Player.Instance.leftHandTransform.rotation;
				LHandVolocityChecker.transform.localPosition = Vector3.zero;
				LHandVolocityChecker.transform.rotation = GorillaLocomotion.Player.Instance.leftHandTransform.rotation;
			}
#endregion

            if (EasyInputs.GetSecondaryButtonDown(EasyHand.LeftHand) && menu != null)
			{
				if (Page == "1")
				{
					Drawsingleclickbutton(ref button1, "Disconnect", 0.12f, 0.3f, ref Page1ButtonActive[1], 1);
					Drawsingleclickbutton(ref button2, "Join Public", 0.08f, 0.2f, ref Page1ButtonActive[2], 2);
					Drawsingleclickbutton(ref button3, "Platforms", 0.04f, 0.1f, ref Page1ButtonActive[3], 3);
					Drawsingleclickbutton(ref button4, "Place Holder", 0f, 0f, ref Page1ButtonActive[4], 4);
					Drawsingleclickbutton(ref button5, "Place Holder", -0.04f, -0.1f, ref Page1ButtonActive[5], 5);
					Drawsingleclickbutton(ref button6, "Place Holder", -0.08f, -0.2f, ref Page1ButtonActive[6], 6);
					Drawsingleclickbutton(ref button7, "Next Page", -0.12f, -0.3f, ref Page1ButtonActive[7], 7);

				}
				if (Page == "2")
				{
					Drawsingleclickbutton(ref button1, "Place Holder", 0.12f, 0.3f, ref Page1ButtonActive[8], 8);
					Drawsingleclickbutton(ref button2, "Place Holder", 0.08f, 0.2f, ref Page1ButtonActive[9], 9);
					Drawsingleclickbutton(ref button3, "Place Holder", 0.04f, 0.1f, ref Page1ButtonActive[10], 10);
					Drawsingleclickbutton(ref button4, "Place Holder", 0f, 0f, ref Page1ButtonActive[11], 11);
					Drawsingleclickbutton(ref button5, "Place Holder", -0.04f, -0.1f, ref Page1ButtonActive[12], 12);
					Drawsingleclickbutton(ref button6, "Back Page", -0.08f, -0.2f, ref Page1ButtonActive[13], 13);
					Drawsingleclickbutton(ref button7, "Next Page", -0.12f, -0.3f, ref Page1ButtonActive[14], 14);

				}
				if (Page == "3")
				{
					Drawsingleclickbutton(ref button1, "Place Holder", 0.12f, 0.3f, ref Page1ButtonActive[15], 15);
					Drawsingleclickbutton(ref button2, "Place Holder", 0.08f, 0.2f, ref Page1ButtonActive[16], 16);
					Drawsingleclickbutton(ref button3, "Place Holder", 0.04f, 0.1f, ref Page1ButtonActive[17], 17);
					Drawsingleclickbutton(ref button4, "Place Holder", 0f, 0f, ref Page1ButtonActive[18], 18);
					Drawsingleclickbutton(ref button5, "Place Holder", -0.04f, -0.1f, ref Page1ButtonActive[19], 19);
					Drawsingleclickbutton(ref button6, "Place Holder", -0.08f, -0.2f, ref Page1ButtonActive[20], 20);
					Drawsingleclickbutton(ref button7, "Back Page", -0.12f, -0.3f, ref Page1ButtonActive[21], 21);

				}
				
			}
            #region Mods
			// Page 1
			if (Page1ButtonActive[1])
            {
				PhotonNetwork.Disconnect();
				if (!PhotonNetwork.InRoom) // super smart technology not in room checker!!!
				{
					Page1ButtonActive[1] = false;

				}
			}
			if (Page1ButtonActive[2])
			{
				PhotonNetwork.JoinRandomRoom();
				if (PhotonNetwork.InRoom) // super smart technology in room checker!!!
				{
					Page1ButtonActive[2] = false;

				}
			}
			if (Page1ButtonActive[3])
            {
				BetterPlatforms("Normal"); // simple platforms technology
			}
			if (Page1ButtonActive[4])
			{
				
			}
			if (Page1ButtonActive[5])
			{

			}
			if (Page1ButtonActive[6])
			{

			}
			if (Page1ButtonActive[7])
			{
				Page = "2"; // Advanced Page Changing Technology!!!
				Page1ButtonActive[7] = false;
			}
			// Page 2
			if (Page1ButtonActive[8])
			{
				
			}
			if (Page1ButtonActive[9])
			{
				
			}
			if (Page1ButtonActive[10])
			{
				
			}
			if (Page1ButtonActive[11])
			{

			}
			if (Page1ButtonActive[12])
			{

			}
			if (Page1ButtonActive[13])
			{
				Page = "1"; // Advanced Page Changing Technology!!!
				Page1ButtonActive[13] = false;
			}
			if (Page1ButtonActive[14])
			{
				Page = "3"; // Advanced Page Changing Technology!!!
				Page1ButtonActive[14] = false;
			}
			// Page 3
			if (Page1ButtonActive[15])
			{
				
			}
			if (Page1ButtonActive[16])
			{
				
			}
			if (Page1ButtonActive[17])
			{
				
			}
			if (Page1ButtonActive[18])
			{

			}
			if (Page1ButtonActive[19])
			{

			}
			if (Page1ButtonActive[20])
			{

			}
			if (Page1ButtonActive[21])
			{
				Page = "2"; // Advanced Page Changing Technology!!!
				Page1ButtonActive[21] = false;
			}
			#endregion

			#region MenuColorChanger
			if (MenuColorType == "normal")
			{
				if (BackColorType == "cyan")
				{
					BackColor = Color.cyan;
				}
				ButtonClicked = Color.green;
				ButtonNotClicked = Color.blue;
				MenuTheme.color = Color.black;
			}
			#endregion
		}

	}
}
